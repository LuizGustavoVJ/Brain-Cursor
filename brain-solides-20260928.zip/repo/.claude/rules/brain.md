---
paths:
  - ".claude/**"
  - "CLAUDE.md"
---

# Mexendo no Brain

Carrega ao editar `.claude/` ou `CLAUDE.md`. Dono do assunto: `engenheiro-de-brain`.

## Camadas — onde cada coisa mora

| Camada | Onde | Regra |
| --- | --- | --- |
| Núcleo | `CLAUDE.md` | só roteamento, regras críticas e gates; meta < 150 linhas |
| Por caminho | `.claude/rules/*.md` com `paths:` | regra que só importa ao tocar certo arquivo |
| Sob demanda | `fluxo-completo.md`, `frota/`, `skills/` | uma referência por assunto |
| Função | `.claude/agents/` | um agente por função, ferramentas mínimas |
| Reflexo | hooks em `settings.json` | se cabe em hook ou permissão, não vira texto |

Número que muda (agentes, etapas, gatilhos) não se escreve em texto: aponte para
`frota.sh grupos`, `frota.sh gatilhos`, `frota.sh modelos`. Modelo pelo custo de errar: haiku
extrai e confere, sonnet escreve com padrão conhecido, opus só em porta única (dinheiro, dado
pessoal, contrato público, schema, causa raiz, arquitetura).

## Propagação

Toda alteração em `.claude/` ou `CLAUDE.md` é replicada em todos os repositórios git de
`/var/www/html/`, na mesma tarefa, sem pedir (autorização permanente do usuário, 21/08/2026).

```bash
bash .claude/scripts/propagar.sh --dry-run   # confere
bash .claude/scripts/propagar.sh             # replica
```

O que não viaja: perfil de ambiente `arquitetura/{ambiente-local,estado-projeto,alteracoes-ambiente-local}-<repo>.md`,
`skills/dominio-*`, `settings.local.json`, `cache/`, `*.lock`, `.mcp.json`, `scripts/homol.sh` e o
que o destino listar em `.claude/proprio.txt`. Repo sem perfil ganha esqueleto `PREENCHER`, nunca
dado copiado. O que sai da origem sai do destino (poda). Backup em `~/backups-brain/<data>/<repo>/`
antes de escrever. `.claude` não versionado entra em `.git/info/exclude`. Só roda a partir do cit.
A fonte da lista é o cabeçalho do próprio script.

## Antes de entregar

`frota.sh lint` limpo, `brain_status.sh` sem pendência, `gerar_plugin.py` e propagação.
